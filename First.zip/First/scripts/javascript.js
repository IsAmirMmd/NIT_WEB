const button = document.getElementById("button");

button.addEventListener("click", () => {
    console.log("اع کلیک کردی که");
    alert("کنسول رو یه نگاه بنداز");
})