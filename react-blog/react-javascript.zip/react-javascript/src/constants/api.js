export const BASE_URL = "http://localhost:3000/api";

export const ARTICLES = `${BASE_URL}/articles`;
